// let y = 8;
// console.log(y%2 ? "Nieparzyste" : "Parzyste");


// const imie = "Ola"
// const name = "aleksandra"


// -----------------
// const a = 2;
// const b = 5;
// for(let i=1;i<=a && i<=b; i++){
//     console.log("Trwa odliczanie", i);
// }

// let i =1;
// while (i<-10){
//     console.log("test",i);
//     i++;
// }



// zadanie
// let str = "";

// for(let i=0;i<5;i++){
//     if(i==0 || i==4){
//         for(let j=0;j<7;j++){
//             str += "*";
//         }
//         str +="\n";
//     } else {
//         if(i==1 || i==3){
//             for(let j=0;j<1;j++){
//                 str += "*_____*";
//             }
//         }
//         str += "\n";
//     }
//         if(i==2){
//             for(let j=0;j<1;j++){
//                 str += "*__*__*"
//             }
//         }
//         str += "\n";
//     }

// console.log(str);





// const osoba={
//     imie: "Joanna",
//     nazwisko: "Nowak"
// }

// console.log(osoba.imie, osoba.nazwisko);

// const tekst = "Siała baba mak"
// console.log(tekst.lenght,tekst.toUpperCase());




// const tab = [1,2,3,4]
// tab[0] = "Alpha"
// console.log(tab);

// const txt = "Ala ma kota";
// txt[0] = "0";
// console.log(txt);
// console.log(txt[0]);




// const txt = "Ala ma kota";
// const nr = 23;
// const bool = true;
// const tab = [1,2,3];
// const ob = {};






// const nr = 10;
// const txt = "Alpha";
// const myArray = [1,2,3];                   
// const ob = {};
// const n = null;

// console.log(typeof nr);
// console.log(typeof txt);
// console.log(typeof myArray);
// console.log(typeof ob);
// console.log(typeof n);
// console.log(typeof zzz);



//
//console.log(Array.isArray(myArray));

//_____________STRINGI___________________________________-
// const text = "Ala ma kota";
// const text1 = 'Ala ma kota, a kot ma Ale';

// const img = "<div class='Element' data-text='test'>"; // ---- na przemian apostrofy ' "
// const txt = "It's a big year";
// const img1 = ",div class=\"Element\" data-test=\"test\">";
// const txt1 = 'It\'a big year';
// const txt2 = 'Ala ma kota';

// let text = "Jesienią, jesienią: <br>";
//     text +="sady się rumienią:<br>";
//     text +="jabuszka rumienią:<br>";
//     text +="pomiędzy zielenią:<br>";

// document.getElementById("example").innerHTML = text;

// let text3 = 'Jesienią, jesienią: <br>
//             sady się rumienią:<br>
//             jabuszka rumienią:<br>
//             pomiędzy zielenią:<br>'

// document.getElementById("example").innerHTML = text3;





// const cena = 100;
// const sztuki = 5;

// const text = "Cena towaru A to: " + cena + " za sztukę. Co daje za sztuki: " + sztuki + " cena łączna: " + cena*sztuki + " zł."
// const text1 = 'Cena towaru A to:  ${cena} za sztukę. Co daje za sztuki:  ${sztuki} cena łączna:  ${cena*sztuki + test(cena)} zł.'


// document.getElementById("example").innerHTML = text1;

// function test(x) {
//     return x*2
// }


// -------pobieranie długości tekstu

// const text = "Zespół Szkół Łączności";

// console.log(text.charAt[7]);
// console.log(text[7]);

// console.log(text.charAt(text.length-1));

// document.getElementById("example").innerHTML = text.length;


//------zamiana liter
// const txt = "Ala ma kota";
// const tab = [...txt];
// tab[0] = "E"
// const newTxt = tab.join("");
// console.log(tab);
//console.log(newTxt);


// const txt = "Ala ma kota";
// console.log(txt.toUpperCase(), txt.toLowerCase());
//--------------------------------
//IndexOf(str), LastIndexOf(str), includes(str)

//console.log("Ala ma kota".indexOf('kot'));


//-----zadanie 1
// const text = "Ala ma psa Azorka";

// if(-text.indexOf('psa')){
// // albo (if (text.indexOf("psa")>=0))
//     console.log("Ala ma psa");
// } else {
//     console.log("Ala nie ma psa");
// }
//---------------

// ~"lorem".indexOf("lo");    //  0 --> -(0+1) --> -1 true
// ~"lorem".indexOf("re");    //  2 --> -(2+1) --> -3 true
// ~"lorem".indexOf("kot");    //  0 --> -(1+1) --> -0 false

//----zadanie 2
// const text = "Ala ma kota";
// console.log(text.startsWith("Ala")); //-- true
// console.log(text.startsWith("ma")); //-- false
// console.log(text.endsWith("kota")); //-- true
//-------------




//________SUBSTRING_______

//   substring(start,stop)
//-----zadanie 1
// const text = "Ala ma kota";
// console.log(text.substring(0,3)); // -- ala
// console.log(text.substring(4)); // -- ma kota
// console.log(text.substring(6,4)); // -- ma (zamieni miejscami)
//---------------


//_______SLICE_______

//slice(start stop);
//----zadanie 1
// const txt = "Ala ma kota"
// console.log(txt.slice(0,3)); // -- ala
// console.log(txt.slice(1,5)); // -- la m
// console.log(txt.slice(4,6)); // -- ma
// console.log(txt.slice(-4,-1)); // -- kot
//console.log(txt.slice(-4)); // -- kota
//---------------

//___SPLIT____

//split(znak, dlugosc)
// const text = "Ala ma kota, a kto ma Alę, Ala go kocha, a Kot ją wcale ;(";
// const parts = text.split (","); //-- po przecnku dzieli
// console.log(parts);


// parts.forEach(function(letter) {
//     console.log(letter.toUpperCase());
// }
// );

//parts.forEach((litery) => {console.log(litery.toUpperCase());});

//-----zadanie 1
// const text = "Ala ma kota";
// const newText = text.replace("kota","chomika");
// console.log(newText);
//---------------

//-------zadanie 2
// const text = "Ola lubi koty, Ola lubi psy";
// const newText = text.replaceAll("Ola","Ela");
// console.log(newText);
//------------------

//------zadanie 3
// const text = "Małopolska";
// for (const litera of text) {
//     console.log(litera);
// }
//-----------------

//------zadanie 3
// const text = "Małopolska";
// [...text].forEach(function(e){
//     console.log(e);
// })
//----------------

//------zadanie 3
// const text = "Małopolska";
// text.split("").forEach(e=>{console.log(e);})
//----------------







// const prace = ["http://naszSerwer.pl/ Jan Kowalski - Projekt_c.psd","http://naszSerwer.pl/ Maks Kupiec - Projekt_f.png"]

// console.log(tab[3] + URL.slice(url.lastIndexOf("//") + 2, url.lastIndexOf("/")));



// let counter = 0;

// function WypisywanieWartosci() {
//     document.querySelector("")
// }
