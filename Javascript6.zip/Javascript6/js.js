// const tab = [];
// const tab1 = [1,2,3,4];
// const tab2 = ["Ala", "Ola"];

// const a = "ZSŁ";
// const b = "100";
// const c = 100;

// const tab3 = [a,b,c, "Małopolska",[1,a],tab2];
// console.log(tab3);




// const tab = new Array(10);
// console.log(tab);
// const tab1 = new Array(10,"Ala", "Ela");
// console.log(tab1);



// const tab = ["Ala","Alex"];
// console.log(tab[1]);


// const myCity = "Kraków";
// console.log(myCity + "!");
// const tab = ["Kraków","Warszawa"];
// console.log(tab[0] + "!");

// const bestCity = tab[0];
// console.log(bestCity.toUpperCase()+" Jest lepszy od ");
// console.log(tab[0].toUpperCase()+" Jest lepszy od ");


//_------------DŁUGOŚĆ-----------------
//index    0    1    2
// const tab = ["1P","2P","3P"];

// console.log(tab.length);
// console.log(tab[tab.length -1]);
//-------------------------------------

// const tab = [1,2,3];
// console.log(tab);
// tab[3] = "Jan";
// console.log(tab);
// tab[tab.length] = "TEST";
// console.log(tab);

// console.log(Array.isArray(tab));


//----------metody push() pop()------------
// const tab = ["1","2","3"];
// tab.push("A");
// tab.push("B",10);
// console.log(tab);

// const lalstElement = tab.pop();
// console.log(tab.pop());
// console.log(tab);
// console.log(lalstElement);
//---------------------------------------


//---------unshift() shift()------------
// const tab = [1,2,3,4];
// console.log(tab);
// // tab.unshift(0,"A");
// // console.log(tab);
// nr = tab.unshift(0,"A");
// console.log(tab, nr);

// const tab = [1,2,3,4];
// console.log(tab);
// // tab.shift();
// // console.log(tab);
// nrDel = tab.shift();
// console.log(tab,nrDel);
//--------------------------------------


//---------join(separator);-------------
// const miniTab = ["Styczeń","Luty","Marzec","Kwiecień","Maj"];

// console.log(miniTab.join());
// console.log(miniTab.join(""));
// console.log(miniTab.join(" "));
// console.log(miniTab.join(", "));
// console.log(miniTab.join(" a po nim "));

// console.log(miniTab.length);
// console.log(miniTab.join("").length);
// ---------------------------------------



//--------spred, split()-----------------
// const myText = "ZSŁ to przyszłość, a wisła płynie";

// const Tab = [...myText];
// console.log(Tab);


// console.log(myText.split(" "));
// console.log(myText.split(", "));
// -----------------------------------------



//------------reverse()-------------------
// const tab = [1,2,3,4,5];
// console.log(tab);
// tab.reverse();
// console.log(tab);
// -------------------------------------




//-----ZADANIE-----------
// let inp = document.querySelector("input");
// let but = document.querySelector("button");

// but.addEventListener("click", () =>{
//     let rev = [...inp.value].reverse().join("");

//     if(inp.value.toUpperCase() == rev.toUpperCase())
//     {
//         alert(true);
//     }
//     else
//     {
//         alert(false);
//     }
// });
//----------------------

//const tab = ["Marta","Anna","Marek","Krzysztof","Wojtek"];
const myData = [1,2,3,4,1,44.1,42.11,44,5,23,2.2,12.3];
let clearData = []

// console.log(tab);
// console.log(tab1);
// console.log(tab.sort());
// console.log(tab1.sort());

// function mySort(a,b){
//     if (a<b) {
//         return - 1
//     }
//     if (a>b) {
//         return 1
//     }
//     return 0
// }

function mySort(a,b){
    return a-b;
}

clearData = myData.slice();
console.log(myData.sort(mySort));