// const people = [
//     {name:"Wojtek", age:9},
//     {name:"Aleksandra", age:19},
//     {name:"Jarema", age:7},
//     {name:"Barbara", age:17},
// ];

// console.log(people);

// people.sort(function name(a,b){
//     return a.age - b.age;
// });

// console.log(people);


//----ZADANIE 1-------
// const eMail = [
//     "marta@onet.pl",
//     "martusia@wp.pl",
//     "marta@interia.pl",
//     "mart@nazwa.pl",
//     "mara@home.pl",
// ]

// eMail.sort(function name(a,b){
//     return a[a.indexOf('@') + 1].localeCompare(b[b.indexOf('@') + 1])
// })

// console.log(eMail);
//---------------------


//--ZADANIE 2------------------
// const people = [
//     {name:"Wojtek", age:9},
//     {name:"Aleksandra", age:12},
//     {name:"Jarema", age:19},
//     {name:"Barbara", age:25},
//     {name:"Wojtek", age:7},
//     {name:"Aleksandra", age:12},
//     {name:"Jarema", age:7},
// ]
// let sortIndex = "name";

// if(sortIndex == "all"){
//     sortIndex = "age";
//         people.sort(mySort)
//     sortIndex = "name";
//         people.sort(mySort)
// } else {
//     people.sort(mySort)
// }
// function mySort(a,b) {
//     if (sortIndex == "age") return a.age - b.age;
//     if(sortIndex == 'name') return a.name.localeCompare(b.name);
// }

// console.log(people);
//-----------------------------

//----zle----------
// people.sort(function name(a,b){
    
//     if(sortIndex == 'name') return a.name.localeCompare(a-b);
//     if(sortIndex == 'age') return a.age - b.age;
//     if(sortIndex == 'all')

// });

// console.log(people);
//--------------------


// const tab1 = ["Ewa", "Wojtek"];
// const tab2 = ["Ewa", "Aleksander"];
// const tab3 = ["Jan", "Magdalena"];

// console.log(tab1.concat(tab2,tab3));

// const bigTable = [...tab1, ...tab2, ...tab3];

// console.log(bigTable);



// const tab = ["Ewa", "Wojtek", "Iza", "Aleksander", "Jan", "Magdalena"];

// console.log(tab);

// console.log(tab.slice(0,1));
// console.log(tab.slice(3));
// console.log(tab.slice());
// console.log(tab.slice(-2));
// console.log(tab.slice());
// console.log(tab.slice(2,-1));

//--------splice(index,ileUsunąć, nowyElement*...)

// console.log(tab.splice(2,1));
// console.log(tab.splice(2,0,"X","Y"));
// console.log(tab.splice(-1,0,"X","Y"));

// console.log(tab);


//----ZADANIE 3-------

// const data = [3,1,3,2,2,1,2,3,2,1,2]
// data.forEach((e, i) => {
//     if(e == 3) {
//         data.splice(i, 1);
//     }
// })

// console.log(data);
//--------------------

// const echo =  new Array(20);
// console.log(echo);
// echo.fill("^.^");
// console.log(echo);

// const brawa = [];
// brawa.length = 15;
// console.log(brawa);
// brawa.fill(">",0,5);
// brawa.fill("<",-5);
// console.log(brawa);

// const myNames = ["Joanna", "Hanka", "Piotr", "Eliza"];
// for(let i=0;i<myNames.length;i++){
//     const oneName = myNames[i].toUpperCase();
//     console.log("Pętla po tablicy:" + 1);
//     console.log(myNames[i]);
//     console.log(oneName);
// }


// for(const oneName of myNames){
//     console.log(oneName);
// }

// const x = ["a", "B", "c", "dD"];

// for(let y of x){
//     console.log(y.toLowerCase());
// }

// const tab = [
//     ["a1", "a2", "a3"],
//     ["b1", "b2", "b3"],
//     ["c1", "c2", "c3"],
// ];
// console.log(tab);
// console.log(tab[0].length);

//map editor.org

// const cars = [
//     ["audi", "red",2014,16500],
//     ["Toyota", "white",2013,36500],
//     ["Subaru", "darkgrey",2015,47500],
// ];
// const ofertaNa = 0; //nr rekordu
// console.log(
//     marka:           ${cars{ofertaNa}[0]}
//     kolor:           ${cars{ofertaNa}[1]}
//     rok produkcji:   ${cars{ofertaNa}[2]}
//     przebieg:        ${cars{ofertaNa}[3]}
// );




const level = [
    [1, 1, 0, 0, 2, 2, 0, 0, 1, 1, 2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1],
    [1, 0, 0, 0, 2, 2, 0, 0, 0, 1, 2, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1],
    [1, 0, 1, 1, 2, 2, 1, 1, 0, 1, 2, 1, 0, 1, 1, 0, 0, 1, 1, 0, 1],
    [1, 0, 2, 2, 2, 2, 2, 2, 0, 1, 2, 1, 0, 2, 2, 2, 2, 2, 2, 0, 1],
    [2, 2, 2, 2, 1, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 1, 2, 2, 1, 1],
    [2, 2, 4, 2, 1, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 1, 2, 2, 1, 1],
    [1, 0, 2, 2, 2, 2, 2, 2, 0, 1, 2, 1, 0, 2, 2, 2, 2, 2, 2, 0, 1],
    [1, 0, 1, 1, 2, 2, 1, 1, 0, 1, 2, 1, 0, 1, 1, 1, 1, 1, 3, 0, 1],
    [1, 0, 0, 0, 2, 2, 0, 0, 0, 1, 2, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1],
    [1, 1, 0, 0, 2, 2, 0, 0, 1, 1, 2, 1, 1, 0, 0, 0, 0, 0, 0, 1, 1]
];


let css = "text-shadow: 0 0 5px #FFF, 0 0 10px #FFF, 0 0 15px #FFF, 0 0 20px #49ff18, 0 0 30px #49FF18, 0 0 40px #49FF18, 0 0 55px #49FF18, 0 0 75px #49ff18;font-size:50px";
console.log("%c Simple Map",css);
level.forEach((arr, arrIn) =>{
    arr.forEach((x, i) => {
        if(x == 1) {
            level[arrIn].splice[1,1, "🟫"]
        } else if(x == 0){
            level[arrIn].splice[1,1, "🟦"]
        }
    })
})
let koniec = [];
level.forEach(level => {
    
})

console.log(koniec);
