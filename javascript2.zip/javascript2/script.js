for (let i = 0; i < 100; i++){
    console.log("lok 1 2 3 test")
}

/**
 * @param id
 * @param number
 * @param parent
 */

function createElementList (id, number, parent){}

//if(confirm('Czy mam usunac system 32?')) {
//    alert("wybrano ciemny motyw strony");
 //   document.body.style.backgroundColor = "grey";
//} else {
//    alert("wybrano jasny motyw strony");
//    document.body.style.backgroundColor = "black";
//}; 



//let y = prompt("Podaj swoje haslo");
//if (y == null){
 //   alert("anulujesz");
//} else if(y == ""){
 //   alert("Nie troluj");
//} else {
//    alert("UwU meow");
//}

