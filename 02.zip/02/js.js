// const btn = document.querySelector('.button');
// console.log(btn);

// btn.innerText = 'Kliknij mnie uwu!';
// btn.setAttribute('title','Kliknij mnie');     //dodawanie atrybutów
// btn.setAttribute('data-kolor',"--czerwony:5");
// btn.classList.add('btn-big');    //dodanie, odjecie remove, podmiana klasy toggle

// --------------------------------------------------------------------------
// const min = 3;
// const max = 10;
// const random = Math.floor(Math.random()* (max-min+1)+ min);
// //Math.floor(2.99) --> 2
// //Math.random() --> [0,1];
// console.log(random);

// --------------------------------------------------------------------------
// const myAge = 10;
// const my_age = 10;

// //bledne nazwy
// const my-age = 10;
// const 2myAge = 10;
// const my age = 10;
// const mójwiek = 10;

// --------------------------------------------------------------------------
//     CONST

// const apiUrl = 'https://tl.krakow.pl';
// apiUrl = 'fff';

// --------------------------------------------------------------------------
// const tab = [1,2,3];
// console.log(tab);
// tab[3] = 4;
// console.log(tab);

// tab = [1,2,3,4];


// --------------------------------------------------------------------------
// const currentUser = {
//     name: 'Jan',
//     age: 20
//     }
// console.log(currentUser)
// currentUser.age = 25;
// console.log(currentUser)

// --------------------------------------------------------------------------
// const name1 = "tomek";
// const name2 = name1.toUpperCase();
// console.log(name2)

// --------------------------------------------------------------------------
// const tab2 = [];

// tab2.push(1,2,3);
// tab2.length = 3;     // OK
// tab2 = [];           // NIE OK
// console.log(tab2);


// --------------------------------------------------------------------------
// let myData = 20;

// console.log(myData);

// {
// let myData = 'Wiek';
//     console.log(myData);
// }

// console.log(myData);

// {
// console.log(myData);


// for (let i=0;i<10;i++){
//     console.log(i);
// }
// console.log(i);


// --------------------------------------------------------------------------
// var xGen = 20;
// function test(){
//     var xGen = 'Gear'
//     console.log(xGen);
// }
// test();
// console.log(xGen);

// --------------------------------------------------------------------------
// var name1 = "Marcin";
// var name1 = 'Karol';
// console.log(name1); //Karol

// let name2 = 'Marcin';
// let name2 = 'Karol'; //błąd = Identifier "name" has already been declared
// console.log(name2);

// --------------------------------------------------------------------------
// var a = 20;
// var ares = 200;
// var adam = 'adam';

// let a1 = 21;
// let ares1 = 201;
// let adam1 = 'adam1';

// console.log(window.a,window.a1);

// --------------------------------------------------------------------------
function alert(data){
    console.log('To jest moja funkcja alert');
}
alert("Uwaga")